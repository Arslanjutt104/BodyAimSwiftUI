//
//  ExerciseDays.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 17/09/2023.
//

import Foundation
import SwiftUI

struct exerciseDaysModel:Identifiable{
    var id : Int
    var dayName:String
    var exerciseStatus:String
    var daysNumber:String
    
}

let exerciseDays:[exerciseDaysModel] = [exerciseDaysModel(id: 1 ,dayName: "Mon", exerciseStatus: "1", daysNumber: "1"),exerciseDaysModel(id: 2, dayName: "Tue", exerciseStatus: "2", daysNumber: "2"),exerciseDaysModel(id:3 ,dayName: "Wed", exerciseStatus: "0", daysNumber: "3"),exerciseDaysModel(id:4 ,dayName: "Thru", exerciseStatus: "0", daysNumber: "4"),exerciseDaysModel(id: 5,dayName: "Fri", exerciseStatus: "0", daysNumber: "5"),exerciseDaysModel(id: 6 ,dayName: "Sat", exerciseStatus: "0", daysNumber: "6"),exerciseDaysModel(id: 7 ,dayName: "Sun", exerciseStatus: "0", daysNumber: "7")]


struct exerciseWeekModel: Identifiable {
    var id = UUID()
    var name: String
    var items: [exerciseDaysModel]
}


let exerciseWeek:[exerciseWeekModel] = [exerciseWeekModel(name: "Week 1", items: exerciseDays),exerciseWeekModel(name: "Week 2", items: exerciseDays),exerciseWeekModel(name: "Week 3", items: exerciseDays)]
