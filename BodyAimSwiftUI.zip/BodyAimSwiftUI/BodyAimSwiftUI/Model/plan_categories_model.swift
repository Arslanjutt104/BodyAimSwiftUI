//
//  plan_categories_model.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 15/09/2023.
//

import Foundation
import SwiftUI


struct plan_categories_model:Identifiable{
    var plan_image:String!
    var plan_title:String!
    var id = UUID()
}


let plan_categories:[plan_categories_model] = [plan_categories_model(plan_image: "plan_body", plan_title: "Full Body"),plan_categories_model(plan_image: "plan_body", plan_title: "ABS"),plan_categories_model(plan_image: "plan_body", plan_title: "Chest"),plan_categories_model(plan_image: "plan_body", plan_title: "Thaii")]


