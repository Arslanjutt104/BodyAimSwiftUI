//
//  ProPlanCardView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 16/09/2023.
//

import SwiftUI

struct ProPlanCardView: View {
    
    //MARK: PROPERTIES

    @State var objPlan:plan_categories_model?
    
    //MARK: BODY
    var body: some View {
        
        ZStack(alignment: .center){
            
            Image((objPlan?.plan_image) ?? "img_placeholder").resizable()
                .frame(width:400,height: 200)
                .clipped()
                .clipShape(RoundedRectangle(cornerRadius: 20))
            
            
            Image("gradient_image").resizable()
                .frame(width:400,height: 200)
                .clipped()
                .clipShape(RoundedRectangle(cornerRadius: 20))
            
                .overlay(alignment: .trailing) {
                    Image("lock_").resizable()
                        .frame(width:40,height: 40)
                        .clipped()
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .padding()
                }
              
            
            
            Text((objPlan?.plan_title) ?? "loading...")
                .foregroundColor(Color("color_plan_title"))
                .fontWeight(.bold)
                .offset(x:-150,y: 70)
                
            
        } //:ZSTACK
    }//:BODY
}


struct ProPlanCardView_Previews: PreviewProvider {
    static var previews: some View {
        ProPlanCardView().previewLayout(.sizeThatFits)
    }
}
