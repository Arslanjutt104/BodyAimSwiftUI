//
//  ProPlans.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 15/09/2023.
//

import SwiftUI

struct ProPlans: View {
    
    //MARK: PROPERTIES
    var my_plan_categores : [plan_categories_model] =  plan_categories
    
    
    //MARK: BODY
    var body: some View {
        
        NavigationView {
                List(my_plan_categores.indices,id: \.self) { index in
                    ZStack {
                        NavigationLink(destination: BaseExerciseView()){
                            EmptyView()
                        }
                        ProPlanCardView(objPlan: my_plan_categores[index])
                       
                       
                    }
                    .listRowBackground(Color.clear)
                    .listRowSeparator(.hidden)
                } //:LIST
                .listStyle(.plain)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem (placement: .principal) {
                    Text("Pro Plan")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                }
            }
        } //:NAVIGATION VIEW
    }//:BODY
}

struct ProPlans_Previews: PreviewProvider {
    static var previews: some View {
        ProPlans()
    }
}
