//
//  NormalPlans.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 15/09/2023.
//

import SwiftUI

struct MyPlans: View {
    
    //MARK: PROPERTIES
    var my_plan_categores : [plan_categories_model] =  plan_categories
    @State var isActivate:Bool =  false
    
    //MARK: BODY
    var body: some View {
        
        NavigationView {
            List(my_plan_categores.indices,id: \.self) { index in
                ZStack {
                    card_plan_view(objPlan: my_plan_categores[index])
                    NavigationLink(destination: BaseExerciseView()){
                        EmptyView()
                    }
                  
                }
                .listRowBackground(Color.clear)
                .listRowSeparator(.hidden)
            } //:LIST
            .listStyle(.plain)
           /* .overlay(alignment:.bottomTrailing) {
                Button {
                    isActivate = true
                   
                    
                } label: {
                    
                    Image(systemName: "plus.circle.fill")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .foregroundColor(Color.orange)
                    
                }.padding()
                NavigationLink(destination: PlansView(),isActive: $isActivate){
                    EmptyView()
                }
            }*/
            
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem (placement: .principal) {
                    Text("My Plan")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                }
            }
        } //:NAVIGATION VIEW
        .navigationBarBackButtonHidden()
    }//:BODY
}

struct NormalPlans_Previews: PreviewProvider {
    static var previews: some View {
        MyPlans()
    }
}
