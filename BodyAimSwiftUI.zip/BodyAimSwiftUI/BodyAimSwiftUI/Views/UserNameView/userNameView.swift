//
//  userNameView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 15/09/2023.
//

import SwiftUI

struct userNameView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct userNameView_Previews: PreviewProvider {
    static var previews: some View {
        userNameView()
    }
}
