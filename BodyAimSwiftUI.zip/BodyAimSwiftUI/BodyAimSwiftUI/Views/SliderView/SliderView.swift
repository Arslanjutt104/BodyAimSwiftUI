//
//  SliderView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 16/09/2023.
//

import SwiftUI

struct SliderView: View {
    
    //MARK: PROPERTIES
    @State var imgHeight:CGFloat
    
    var action: () -> Void
    
    //MARK: BODY
    var body: some View {
        
        GeometryReader { proxy in
            
            ZStack {
                Image("slider_image")
                    //.resizable()
                    .scaledToFit()
                .frame(maxWidth: .infinity,maxHeight: 200)
                .overlay(alignment: .topLeading){
                    HStack(spacing:40){
                        Button {
                            print("SAVE")
                            action()
                        } label: {
                            Image("arrow_backward copy")
                                .resizable()
                                .frame(width: 15,height: 25)
                                .foregroundColor(.white)
                        }
                        
                        Text("Full Body")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                        Spacer()
                       
                    }//:HSTACK
                    .padding(.leading,20)
                    .padding(.top,40)
                }
            }//:ZTACK
            
        }//:GEOMTERY
    }//:BODY
}

struct SliderView_Previews: PreviewProvider {
    static var previews: some View {
        SliderView(imgHeight: 100, action:{}).previewLayout(.sizeThatFits)
    }
}
