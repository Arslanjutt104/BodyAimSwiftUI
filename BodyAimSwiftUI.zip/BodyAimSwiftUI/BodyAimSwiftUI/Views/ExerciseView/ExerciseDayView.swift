//
//  ExerciseDayView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 16/09/2023.
//

import SwiftUI

struct ExerciseDayView: View {
    
    //MARK: PROPERTIES
    @State var exerciseModel:[exerciseDaysModel] = exerciseDays
    @State private var gridColumn:Double = 4.0
    @Binding var selectExerciseID:Int
    //MARK: BODY
    var body: some View {
        //MARK: LazyVGrid
        LazyVGrid(columns: Array(repeating: .init(.flexible()), count: Int(gridColumn)), alignment: .center, spacing: 10){
            ForEach(exerciseModel) { item in
                VStack {
                    ZStack {
                        
                        if item.exerciseStatus == "1"{
                            Image("Tick")
                                .resizable()
                                .frame(width: 60, height: 60, alignment: .center)
                            
                        }else if item.exerciseStatus == "2"{
                            Image("lock_exercise")
                                .resizable()
                                .frame(width: 60, height: 60, alignment: .center)
                            
                            Text(item.daysNumber)
                                .fontWeight(.semibold)
                                .font(.system(size:16))
                        }else{
                            LinearGradient(colors: [Color("color_yellow"),Color("color_dark_yellow"),Color("color_dark_yellow")], startPoint: .topLeading, endPoint: .bottomTrailing).clipShape(Circle())
                                .frame(width: 60, height: 60, alignment: .center)
                            
                            Text(item.daysNumber)
                                .fontWeight(.semibold)
                                .font(.system(size:16))
                        }
                      
                    }//:ZSTACK
                    Text(item.dayName)
                        .fontWeight(.medium)
                        .font(.system(size:16))
                        .foregroundColor(item.exerciseStatus == "1" || item.exerciseStatus == "2" ? .black : .gray)
                }//:VSTACK
                .padding()
                .onTapGesture {
                    selectExerciseID = item.id
                    print("Tapped item with ID: \(item.id)")
                }
            }//:FOR EACH
        }//:LAZY HGRID
        .overlay {
            RoundedRectangle(cornerRadius: 20).stroke(lineWidth: 1.0)
                .foregroundColor(Color("color_tf_border"))
        }
        
    }
}

struct ExerciseDayView_Previews: PreviewProvider {
    static var previews: some View {
        ExerciseDayView(selectExerciseID: .constant(0)).previewLayout(.sizeThatFits)
    }
}
