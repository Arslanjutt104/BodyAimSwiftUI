//
//  ExerciseListView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 17/09/2023.
//

import SwiftUI

struct ExerciseListView: View {
    
    @State var exerciseModel:[exerciseWeekModel] = exerciseWeek
    @State var showWorkOut = false
    @Binding var exerciseId:Int
    //MARK: PROPETIES
    
    //MARK: BODY
    var body: some View {
        List {
            ForEach(exerciseModel) { exercise in
                VStack(alignment: .leading){
                    Text(exercise.name).font(.title2)
                    ExerciseDayView(exerciseModel: exercise.items, selectExerciseID: $exerciseId)
                  
                }
            }//:FOR EACH
            .listRowSeparator(.hidden)
        }//:LIST
        .listStyle(.plain)
    }//BODY
}

struct ExerciseListView_Previews: PreviewProvider {
    static var previews: some View {
        ExerciseListView(exerciseId: .constant(0))
    }
}
