//
//  SettingCardView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 16/09/2023.
//

import SwiftUI

struct SettingCardView: View {
    
    //MARK: PROPETIES
    @Binding var setting_name :String
    //MARK: BODY
    
    var body: some View {
       
        ZStack {

            LinearGradient(
                gradient: Gradient(colors: [Color("color_dark_yellow"),Color("color_yellow")]),
                startPoint: .bottomTrailing,
                endPoint: .topLeading
            )//:LinearGradient
            
            .frame(maxWidth:.infinity,minHeight: 60,maxHeight: 60)
            
            .cornerRadius(10)
            
            HStack(){
                Text(setting_name)
                    .font(.system(size: 24))
                    .fontWeight(.semibold)
                
                Spacer()
                
                Image("arrow_forward")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height: 20, alignment: .center)
            }//:HSTACK.
            .padding()
        }//:ZSTACK
        .padding()
    }
}

struct SettingCardView_Previews: PreviewProvider {
    static var previews: some View {
        SettingCardView(setting_name: .constant("Edit Profile")).previewLayout(.sizeThatFits)
    }
}
