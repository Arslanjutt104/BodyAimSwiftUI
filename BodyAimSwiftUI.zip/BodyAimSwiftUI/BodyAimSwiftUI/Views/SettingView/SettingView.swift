//
//  SettingView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 16/09/2023.
//

import SwiftUI

struct SettingView: View {
    
    
    //MARK: PROPERTIES
    
    @State var arrSetting = ["Edit Profile","Rate this app","Tell a friends","Privacy Policy","Terms of use"]
    
    //MARK: BODY
    
    var body: some View {
    
        NavigationView(){
            List {
                ForEach($arrSetting , id:\.self) { item in
                    ZStack {
                        
                        NavigationLink(destination: EditProfile()){
                           EmptyView()
                        }
                        SettingCardView(setting_name: item)
                    }
                }
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets())
                .listRowSeparator(.hidden)
                
            }//:LIST

            .listStyle(.plain)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem (placement: .principal) {
                    Text("Settings")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                }
            }//:TOOLBAR ITEM
        }//NAVIGATION_VIEW
        .navigationBarBackButtonHidden(true)
    }//:BODY
} //:SETTING

struct SettingView_Previews: PreviewProvider {
    static var previews: some View {
        SettingView()
    }
}
