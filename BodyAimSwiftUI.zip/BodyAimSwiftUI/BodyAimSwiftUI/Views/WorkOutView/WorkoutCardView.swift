//
//  WorkoutCardView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 18/09/2023.
//

import SwiftUI

struct WorkoutCardView: View {
    
    //MARK: PROPRTIES
    @State var workoutImage:String = ""
    @State var cellWidth: CGFloat
    @State var cellHeight: CGFloat
    //MARK: BODY
    
    var body: some View {
        
        ZStack {
            RoundedRectangle(cornerRadius: 16).stroke(Color.gray, lineWidth: 1.0)
            HStack(spacing: 40){
                
                Image("Push-Ups").resizable().scaledToFit().frame(width: 80,height: 80).padding(.leading,20)
                
                RoundedRectangle(cornerRadius: 16).stroke(Color("color_light_gray"), lineWidth: 1.0).frame(width: 1.0, height: 120, alignment: .center)
                
                VStack(alignment:.leading){
                    Text("Push-Ups").font(.title3).foregroundColor(Color.gray)
                    Text("10 - X4").font(.subheadline).foregroundColor(Color.gray)
                }//:VSTACK
                
                .padding()
                Spacer()
            }//:HSTACK
        }//:ZSTACK
        .frame(width: cellWidth, height: cellHeight) // Adjust the card size as needed
    }//:BODY
}

struct WorkoutCardView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutCardView(cellWidth: 400, cellHeight: 100).previewLayout(.sizeThatFits)
    }
}
