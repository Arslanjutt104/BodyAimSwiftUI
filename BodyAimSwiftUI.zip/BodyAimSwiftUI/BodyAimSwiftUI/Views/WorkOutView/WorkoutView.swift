//
//  WorkoutView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 16/09/2023.
//

import SwiftUI

struct WorkoutView: View {
    
    var body: some View {
        
        GeometryReader { proxy in
            List {
                ForEach(0..<8) { item in
                    WorkoutCardView(cellWidth: proxy.size.width * 0.9, cellHeight: proxy.size.width * 0.25)
                }
                .listRowSeparator(.hidden)
            }.listStyle(.plain)
        }
    }
}

struct WorkoutView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutView()
    }
}
