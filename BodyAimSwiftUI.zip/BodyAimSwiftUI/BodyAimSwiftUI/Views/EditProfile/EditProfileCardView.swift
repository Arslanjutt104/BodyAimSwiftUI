//
//  EditProfileCardView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 16/09/2023.
//

import SwiftUI

struct EditProfileCardView: View {

    //MARK: PROPERTIES
    
    @Binding var user_name:String
    @Binding var lblTitle:String
    
    
    //MARK: BODY
    var body: some View {
        ZStack(){
            HStack(){
                Text(user_name)
                    .font(.title2)
                    .fontWeight(.medium)
                
                Spacer()
                
                Text(lblTitle)
                    .font(.title2)
                
            }  //:HSTACK
            .padding()
        }//:ZSTACK
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color("color_tf_border"), lineWidth: 1)
        ).padding()
    }
}

struct EditProfileCardView_Previews: PreviewProvider {
    static var previews: some View {
        EditProfileCardView(user_name: .constant("Name"), lblTitle: .constant("Arslan")).previewLayout(.sizeThatFits)
    }
}
