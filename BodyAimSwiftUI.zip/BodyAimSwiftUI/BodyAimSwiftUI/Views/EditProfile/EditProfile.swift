//
//  EditProfile.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 16/09/2023.
//

import SwiftUI

struct EditProfile: View {
    
    //MARK: PROPERTIES
    @State var user_name:String = "iOS"
    @State var user_gender:String = "Male"
    @State var user_age:String = "26"
    @State var user_height:String = "5.7"
    @State var user_weight:String = "70"
    @State var user_diseases:String = "No"
    
    @Environment(\.presentationMode) var presentationMode
    //MARK: BODY
    
    var body: some View {
        
        
        NavigationView {
            VStack {
                customNavigationView(navigationTitle: .constant("Edit Profile")){
                    self.presentationMode.wrappedValue.dismiss()
                }
                
                GeometryReader { geometry in
                    VStack(){
                        EditProfileCardView(user_name: .constant("Name"), lblTitle: $user_name)
                        
                        EditProfileCardView(user_name: .constant("Gender"), lblTitle: $user_gender)
                        
                        EditProfileCardView(user_name: .constant("Age"), lblTitle: $user_age)
                        
                        EditProfileCardView(user_name: .constant("Height"), lblTitle: $user_height)
                        
                        EditProfileCardView(user_name: .constant("Weight"), lblTitle: $user_weight)
                        
                        EditProfileCardView(user_name: .constant("Disease"), lblTitle: $user_diseases)
                        
                        Spacer()
                        
                        buttonView(buttonWidth: geometry.size.width * 0.9, buttonHeight: 50, buttonTitle: "Save") {
                            self.presentationMode.wrappedValue.dismiss()
                            print("save edit value")
                        }.modifier(buttonBackgroundGradientColor())
                        
                        Spacer()
                    } //:VSTACK
                } //:GEOMETRY READER
                .padding(.top,20)
            }
          
        }//NAVIGATIONVIEW
        .navigationBarBackButtonHidden(true)
    }//:BODY
}

struct EditProfile_Previews: PreviewProvider {
    static var previews: some View {
        EditProfile()
    }
}
