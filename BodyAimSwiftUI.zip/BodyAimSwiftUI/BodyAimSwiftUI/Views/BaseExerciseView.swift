//
//  BaseExerciseView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 16/09/2023.
//

import SwiftUI

struct BaseExerciseView: View {
    
    //MARK: PROPETIES
    @State var buttonWorkout = "Workout"
    @State var buttonMeal    = "Meal"
    @State var isTapBtnWorkOut:Bool =  true
    @State var exerciseId:Int =  0
    
    @Environment(\.presentationMode) var presentatonMode
    
    //MARK: BODY
    var body: some View {
        
        NavigationView {
            
            
            
            GeometryReader { proxy in
                
                VStack {
                    
                    TabView {
                        SliderView(imgHeight: proxy.size.height * 0.3){
                            self.presentatonMode.wrappedValue.dismiss()
                        }
                    }.frame(height: proxy.size.height * 0.2)
                    
                    HStack {
                        buttonView(buttonWidth:proxy.size.height * 0.5 , buttonHeight:  60, buttonTitle:buttonWorkout){
                            print("WorkOut tap")
                            isTapBtnWorkOut = true
                        }
                        .modifier(buttonBackgroundGradientColor())
                        
                        buttonView(buttonWidth: proxy.size.height * 0.5 , buttonHeight: 60, buttonTitle: buttonMeal){
                            print("Meal tap")
                            isTapBtnWorkOut = false
                        }
                        .modifier(buttonBorderColor())
                        
                    } //:HSTACK
                    
                    Spacer()
                    if isTapBtnWorkOut{
                        if exerciseId == 0 {
                            ExerciseListView(exerciseId: $exerciseId)
                        }else{
                            WorkoutView()
                        }
                    }else{
                        
                        MealView()
                        
                    }
                }
            }//:VSTACK
        }//:NAVIGATION VIEW
        .edgesIgnoringSafeArea(.top)
        .navigationBarBackButtonHidden(true)
    }//:BODY
        
}

struct BaseExerciseView_Previews: PreviewProvider {
    static var previews: some View {
        BaseExerciseView()
    }
}
