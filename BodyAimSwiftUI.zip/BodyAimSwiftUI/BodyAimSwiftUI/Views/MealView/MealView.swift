//
//  MealView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 16/09/2023.
//

import SwiftUI

struct MealView: View {
    
    //MARK: PROPERTIES
    
    //MARK: BODY
    var body: some View {
        
        VStack(alignment:.leading) {
            
            Text("04 Meal").font(.headline)
                .multilineTextAlignment(.leading)
                .padding(.leading,20)
            
            List {
                ForEach(0..<6){ _ in
                    MealCardView()
                }
                .listRowSeparator(.hidden)
            }.listStyle(.plain)
        }
    }
}

struct MealView_Previews: PreviewProvider {
    static var previews: some View {
        MealView()
    }
}
