//
//  MealCardView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 19/09/2023.
//

import SwiftUI

struct MealCardView: View {
    
    //MARK: PROPERTIES
    @State var cellHeight:CGFloat = 200
    //MARK: BODY
    
    var body: some View {
        VStack(alignment: .leading) {

            HStack(alignment: .center, spacing: 20) {
                Image("Meal")
                    .resizable()
                    .frame(width: 120, height: 120)
                
                VStack(spacing: 5) {
                    Text("Break Fast")
                        .font(.title2)
                        .fontWeight(.medium)
                        .multilineTextAlignment(.leading)
                        .lineLimit(2)
                    Text("07:00 AM")
                        .font(.callout)
                }
                Spacer()
                   
            }
            .modifier(MealBackgroundGradientColor())
                .cornerRadius(12)
            //:HSTACK
            
          
            
            HStack(){
                
                VStack(spacing: 5) {
                    Image("Caleroies")
                        .resizable()
                        .frame(width: 40, height: 40, alignment: .center)
                    Text("Calories")
                        .font(.footnote)
                    Text("300")
                        .font(.footnote)
                }
                Spacer()
                VStack(spacing: 5) {
                    Image("protein")
                        .resizable()
                        .frame(width: 40, height: 40, alignment: .center)
                    Text("Protein")
                        .font(.footnote)
                    Text("10")
                        .font(.footnote)
                }
                Spacer()
                VStack(spacing: 5) {
                    Image("carb")
                        .resizable()
                        .frame(width: 40, height: 40, alignment: .center)
                    Text("Carbs")
                        .font(.footnote)
                    Text("50")
                        .font(.footnote)
                }
                Spacer()
                VStack(spacing: 5) {
                    Image("Fat")
                        .resizable()
                        .frame(width: 40, height: 40, alignment: .center)
                    Text("Fats")
                        .font(.footnote)
                    Text("6")
                        .font(.footnote)
                }
            }//:HSTACK
            
            .padding(.leading, 10)
            .padding(.trailing, 10)
            .padding(.bottom, 10)
            
            
        } //:VSTACK
        .frame(maxWidth: .infinity)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.gray, lineWidth: 1.0)
        )
    }//:BODY
    
}//:MEALCARDVIEW

struct MealCardView_Previews: PreviewProvider {
    static var previews: some View {
        MealCardView().previewLayout(.sizeThatFits)
    }
}
