//
//  TabbarView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 19/09/2023.
//

import SwiftUI

struct TabbarView: View {
    
    
    //MARK: PROPETIES
    
    //MARK: BODY

    var body: some View {
        
        NavigationView {
            TabView {
                
                MyPlans().tabItem {
                    Image("workout")
                    Text("My plans")
                }
                
                ProPlans().tabItem {
                    Image("pro_plan")
                    Text("Pro Plans")
                }
                
                SettingView().tabItem {
                    Image("setting")
                    Text("Setting")
                }
                
            } //:TABVIEW
            .navigationBarHidden(true)
        }//:NAVIGATIONVEIEW
        .navigationBarBackButtonHidden(true)
        
        
    }//:BODY
}

struct TabbarView_Previews: PreviewProvider {
    static var previews: some View {
        TabbarView()
    }
}
