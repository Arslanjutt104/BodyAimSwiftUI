//
//  ContentView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 15/09/2023.
//

import SwiftUI
import CoreData

struct PlansView: View {

    //MARK: PROPERTIES
    
    var plan_categores : [plan_categories_model] =  plan_categories

    //MARK: BODY
    var body: some View {
        
        NavigationView {
            VStack(alignment: .center) {
                
                Text("What area do you want to focus on in your plan?")
                    .font(.title2)
                    .multilineTextAlignment(.center)
                   
                List(plan_categores.indices,id: \.self) { index in
                   
                    
                    ZStack {
                        card_plan_view(objPlan: plan_categores[index])
                        NavigationLink(destination: TabbarView()) {
                           EmptyView()
                        }
                    }
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
                }.listStyle(PlainListStyle()).scrollContentBackground(.hidden)
            }//:VSTACK
            .padding(.top,20)
        } //:NAVIGTIONVIEW
        .navigationBarBackButtonHidden(true)
      
    }//:BODY
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        PlansView()
    }
}
