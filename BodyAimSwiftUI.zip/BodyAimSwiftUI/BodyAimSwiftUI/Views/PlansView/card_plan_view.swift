//
//  card_plan_view.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 15/09/2023.
//

import SwiftUI

struct card_plan_view: View {
    
    //MARK: PROPERTIES

    @State var objPlan:plan_categories_model?
    
    //MARK: BODY
    var body: some View {
        
        ZStack(alignment: .center){
            
            Image((objPlan?.plan_image) ?? "img_placeholder").resizable()
                .frame(width:400,height: 200)
                .clipped()
                .clipShape(RoundedRectangle(cornerRadius: 20))
            
            
            
            
            Text((objPlan?.plan_title) ?? "loading...")
                .foregroundColor(Color("color_plan_title"))
                .fontWeight(.bold)
                .offset(x:-150,y: 70)
                
            
        } //:ZSTACK
    }//:BODY
}

struct card_plan_view_Previews: PreviewProvider {
    static var previews: some View {
        card_plan_view().previewLayout(.sizeThatFits)
    }
}
