//
//  buttonView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 17/09/2023.
//

import SwiftUI

struct buttonView: View {
    
    //MARK: PROPETIES
    @State   var buttonWidth  : CGFloat
    @State   var buttonHeight : CGFloat
    @State   var buttonTitle  : String
    var action: () -> Void
    
    //MARK: BODY
    var body: some View {
        Button {
            action()
        } label: {
            Text(buttonTitle)
                .font(.title2)
                .fontWeight(.medium)
                .foregroundColor(Color.black)
        }.frame(maxWidth: buttonWidth,maxHeight: buttonHeight)
    }
}
