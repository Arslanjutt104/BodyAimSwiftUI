//
//  customNavigationView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 16/09/2023.
//

import SwiftUI

struct customNavigationView: View {
    
    //MARK: PROPETIES
    @Binding var navigationTitle:String
    var action:() -> Void
    
    //MARK: BODY
    
    var body: some View {
            HStack{
                Button {
                    print("SAVE")
                    action()
                } label: {
                    Image("arrow_backward copy")
                        .resizable()
                        .foregroundColor(Color.black)
                        .frame(width: 15,height: 25)
                }.padding(.leading,15)

                Spacer()
                Text(navigationTitle)
                    .multilineTextAlignment(.center)
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(Color.black)
                Spacer()
               
            }//:HSTACK
            .padding(.bottom,40)
            .frame(maxWidth: .infinity,maxHeight: 80)
       
    }
}

struct customNavigationView_Previews: PreviewProvider {
    static var previews: some View {
        customNavigationView(navigationTitle: .constant("Navigation Title"), action: {}).previewLayout(.sizeThatFits)
    }
}
