//
//  BodyAimSwiftUIApp.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 15/09/2023.
//

import SwiftUI

@main
struct BodyAimSwiftUIApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            PlansView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
