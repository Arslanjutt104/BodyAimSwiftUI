//
//  ExtensionView.swift
//  BodyAimSwiftUI
//
//  Created by Mac on 17/09/2023.
//

import Foundation
import SwiftUI


struct buttonBackgroundGradientColor:ViewModifier{
    func body(content: Content) -> some View {
        content
            .background(LinearGradient(colors: [Color("color_yellow"),Color("color_dark_yellow"),Color("color_dark_yellow")], startPoint: .topLeading, endPoint: .bottomTrailing))
            .cornerRadius(10)
            .padding()
    }
}
struct buttonBorderColor:ViewModifier{
    func body(content: Content) -> some View {
        content
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color("color_tf_border"), lineWidth: 1.0)
            ).padding()
    }
}


struct MealBackgroundGradientColor:ViewModifier{
    func body(content: Content) -> some View {
        content
            .background(LinearGradient(colors: [Color("color_yellow"),Color("color_dark_yellow"),Color("color_dark_yellow")], startPoint: .topLeading, endPoint: .bottomTrailing)).clipped()
            .shadow(radius: 10)
    }
}
